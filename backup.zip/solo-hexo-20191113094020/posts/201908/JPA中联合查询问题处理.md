title: JPA 中联合查询问题处理
date: '2019-08-07 14:24:20'
updated: '2019-08-07 14:24:52'
tags: [Java, JPA, Hibernate]
permalink: /articles/2019/08/07/1565159060461.html
---
在使用Jpa中使用了@ManyToOne和@OneToMany，在多条件查询中出现问题，处理成功作为一次记录。

问题描述：

user 使用 @OneToMany

order 使用 @ManyToOne

需求结果：order的分页数据查询条件搜索中带有user的属性，需要通过Jpa查询处理。

处理方法：
```
Specification<PlaceOrder> spec = new Specification<PlaceOrder>() {
            @Override
            public Predicate toPredicate(Root<Orders> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                List<Predicate> list = new ArrayList<>();
                if (conditions.containsKey("username")) {
                    list.add(cb.like(root.get("user").get("username"), (String) conditions.get("username")));
                }
                query.orderBy(cb.desc(root.get("id")));
                Predicate[] predicates = new Predicate[list.size()];
                predicates = list.toArray(predicates);
                return cb.and(predicates);
            }
        };
 return placeOrderDao.findAll(spec, PageRequest.of(page - 1, limit));
```
针对使用 @MangToOne：root.get("实体对象").get("实体对象的属性") 来获取属性

针对使用 @MangToMang：需使用root.join(); 

例如：
```
Join<Orders, User> join = root.join("orderUser", JoinType.INNER);
list.add(cb.like(join.get("username"), (String) conditions.get("username")));
```
