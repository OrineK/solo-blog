title: 一个简单的spring-boot-security JPA demo 记录
date: '2019-10-28 17:13:38'
updated: '2019-10-28 17:13:38'
tags: [JPA, spring-boot, security, jwt]
permalink: /articles/2019/10/28/1572254018307.html
---
![](https://img.hacpai.com/bing/20180817.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

由于我的项目很多都是使用spring-boot和JPA搭建起来的，对于身份状态也比较过shiro和security，最终在统一上选择了security的这种方案，闲暇时间写个记录方便以后查阅。  
使用spring-boot好处就在于可以快速搭建项目，省掉很多配置的时间浪费。  
demo中代码简单所以省略很多注释，可以直接下载运行。  
需要注意：

1. 需要建立对应的数据库，由于是Jpa所以建好库就行，不用建表，表会在项目运行时自动创建。

2.本次demo是简单demo，所以数据配置很简单，如果需要多角色多权限的可以不用下载查看或者下载自己修改。  
最后附上我的demo地址:[https://github.com/OrineK/spring-boot-demo1](https://links.jianshu.com/go?to=https%3A%2F%2Fgithub.com%2FOrineK%2Fspring-boot-demo1)
