title: JPA复杂查询
date: '2019-08-23 17:27:46'
updated: '2019-08-23 17:27:46'
tags: [JPA, Java, Hibernate]
permalink: /articles/2019/08/23/1566552466558.html
---
记录转载文章：
地址：[](https://)https://blog.wuwii.com/jpa-specification.html
